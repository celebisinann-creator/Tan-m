package com.example

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.example.alarm.AlarmScheduler
import com.example.alarm.ExerciseAlarmReceiver
import com.example.alarm.TimerDoneReceiver
import com.example.data.db.AppDatabase
import com.example.data.repository.ExerciseRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BogazApp : Application() {

    lateinit var database: AppDatabase
        private set

    lateinit var repository: ExerciseRepository
        private set

    override fun onCreate() {
        super.onCreate()
        database = AppDatabase.getInstance(this)
        repository = ExerciseRepository(database.exerciseDao())

        createNotificationChannels()

        // Ensure default alarms exist and are scheduled
        CoroutineScope(Dispatchers.IO).launch {
            repository.ensureDefaultAlarms()
            val alarms = repository.getAllAlarmsList()
            for (alarm in alarms) {
                if (alarm.isEnabled) {
                    AlarmScheduler.scheduleAlarm(this@BogazApp, alarm)
                }
            }
        }
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(NotificationManager::class.java)

            val alarmChannel = NotificationChannel(
                ExerciseAlarmReceiver.CHANNEL_ID,
                ExerciseAlarmReceiver.CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Günlük planlanmış boğaz egzersiz alarmları"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 700, 300, 700, 300, 1000)
            }

            val timerChannel = NotificationChannel(
                TimerDoneReceiver.CHANNEL_ID,
                TimerDoneReceiver.CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "3 dakikalık egzersiz süresi bittiğinde çalan alarm"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 200, 500, 200, 800)
            }

            notificationManager?.createNotificationChannel(alarmChannel)
            notificationManager?.createNotificationChannel(timerChannel)
        }
    }
}
