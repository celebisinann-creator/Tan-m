package com.example.ui

import android.app.Application
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.BogazApp
import com.example.alarm.AlarmScheduler
import com.example.alarm.SoundVibrationHelper
import com.example.data.model.AlarmItem
import com.example.data.model.ExerciseLog
import com.example.data.model.ExerciseType
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class TodayStats(
    val bogaz1Count: Int = 0,
    val bogaz2Count: Int = 0,
    val bogaz3Count: Int = 0,
    val bogaz4Count: Int = 0,
    val totalCount: Int = 0,
    val totalMinutes: Int = 0
)

class ExerciseViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = (application as BogazApp).repository

    private val _selectedExercise = MutableStateFlow(ExerciseType.BOGAZ_1)
    val selectedExercise: StateFlow<ExerciseType> = _selectedExercise.asStateFlow()

    private val _remainingSeconds = MutableStateFlow(180)
    val remainingSeconds: StateFlow<Int> = _remainingSeconds.asStateFlow()

    private val _isTimerRunning = MutableStateFlow(false)
    val isTimerRunning: StateFlow<Boolean> = _isTimerRunning.asStateFlow()

    private val _isTimerPaused = MutableStateFlow(false)
    val isTimerPaused: StateFlow<Boolean> = _isTimerPaused.asStateFlow()

    private val _showCompletionDialog = MutableStateFlow<ExerciseType?>(null)
    val showCompletionDialog: StateFlow<ExerciseType?> = _showCompletionDialog.asStateFlow()

    private var timerJob: Job? = null
    private var timerTargetElapsedMillis: Long = 0L

    // Alarms flow
    val alarms: StateFlow<List<AlarmItem>> = repository.allAlarms
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Today logs and stats
    val todayLogs: StateFlow<List<ExerciseLog>> = repository.getTodayLogs()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val todayStats: StateFlow<TodayStats> = todayLogs.map { logs ->
        var c1 = 0
        var c2 = 0
        var c3 = 0
        var c4 = 0
        for (log in logs) {
            when (log.exerciseId) {
                1 -> c1++
                2 -> c2++
                3 -> c3++
                4 -> c4++
            }
        }
        val total = c1 + c2 + c3 + c4
        TodayStats(
            bogaz1Count = c1,
            bogaz2Count = c2,
            bogaz3Count = c3,
            bogaz4Count = c4,
            totalCount = total,
            totalMinutes = total * 3
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = TodayStats()
    )

    fun selectExercise(exercise: ExerciseType, autoStart: Boolean = true) {
        SoundVibrationHelper.triggerClickHaptic(getApplication())
        stopTimerInternal()
        _selectedExercise.value = exercise
        _remainingSeconds.value = exercise.defaultDurationSeconds
        _isTimerPaused.value = false

        if (autoStart) {
            startTimer()
        }
    }

    fun startTimer() {
        SoundVibrationHelper.triggerClickHaptic(getApplication())
        val currentSeconds = if (_remainingSeconds.value <= 0) {
            _selectedExercise.value.defaultDurationSeconds
        } else {
            _remainingSeconds.value
        }
        _remainingSeconds.value = currentSeconds

        timerTargetElapsedMillis = SystemClock.elapsedRealtime() + (currentSeconds * 1000L)
        _isTimerRunning.value = true
        _isTimerPaused.value = false

        // Schedule background alarm
        AlarmScheduler.scheduleTimerEnd(getApplication(), _selectedExercise.value.id, currentSeconds)

        startTickingLoop()
    }

    fun pauseTimer() {
        SoundVibrationHelper.triggerClickHaptic(getApplication())
        if (!_isTimerRunning.value) return

        syncRemainingWithElapsed()
        stopTimerInternal()
        _isTimerRunning.value = false
        _isTimerPaused.value = true

        AlarmScheduler.cancelTimerEnd(getApplication())
    }

    fun resumeTimer() {
        startTimer()
    }

    fun resetTimer() {
        SoundVibrationHelper.triggerClickHaptic(getApplication())
        stopTimerInternal()
        _remainingSeconds.value = _selectedExercise.value.defaultDurationSeconds
        _isTimerRunning.value = false
        _isTimerPaused.value = false

        AlarmScheduler.cancelTimerEnd(getApplication())
    }

    private fun startTickingLoop() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (isActive && _isTimerRunning.value) {
                delay(200)
                val diffMillis = timerTargetElapsedMillis - SystemClock.elapsedRealtime()
                val secondsLeft = ((diffMillis + 999) / 1000).toInt()

                if (secondsLeft <= 0) {
                    _remainingSeconds.value = 0
                    handleTimerCompleted()
                    break
                } else {
                    _remainingSeconds.value = secondsLeft
                }
            }
        }
    }

    private fun syncRemainingWithElapsed() {
        if (_isTimerRunning.value && timerTargetElapsedMillis > 0) {
            val diffMillis = timerTargetElapsedMillis - SystemClock.elapsedRealtime()
            val secondsLeft = ((diffMillis + 999) / 1000).toInt().coerceAtLeast(0)
            _remainingSeconds.value = secondsLeft
        }
    }

    private fun handleTimerCompleted() {
        stopTimerInternal()
        _isTimerRunning.value = false
        _isTimerPaused.value = false
        _remainingSeconds.value = 0

        val finishedExercise = _selectedExercise.value
        AlarmScheduler.cancelTimerEnd(getApplication())

        // Sound + Vibration
        SoundVibrationHelper.playAlertSound(getApplication(), isAlarm = true)
        SoundVibrationHelper.triggerVibration(getApplication(), longArrayOf(0, 600, 200, 600, 200, 900))

        // Record in Database
        viewModelScope.launch {
            repository.recordCompletedExercise(finishedExercise.id, finishedExercise.defaultDurationSeconds)
        }

        // Show dialog
        _showCompletionDialog.value = finishedExercise
    }

    fun dismissCompletionDialog() {
        SoundVibrationHelper.stopSound()
        _showCompletionDialog.value = null
        _remainingSeconds.value = _selectedExercise.value.defaultDurationSeconds
    }

    fun onAppForegrounded() {
        if (_isTimerRunning.value) {
            val diffMillis = timerTargetElapsedMillis - SystemClock.elapsedRealtime()
            val secondsLeft = ((diffMillis + 999) / 1000).toInt()
            if (secondsLeft <= 0) {
                _remainingSeconds.value = 0
                handleTimerCompleted()
            } else {
                _remainingSeconds.value = secondsLeft
            }
        }
    }

    private fun stopTimerInternal() {
        timerJob?.cancel()
        timerJob = null
    }

    // --- Alarms Management ---
    fun toggleAlarm(alarm: AlarmItem) {
        SoundVibrationHelper.triggerClickHaptic(getApplication())
        val updated = alarm.copy(isEnabled = !alarm.isEnabled)
        viewModelScope.launch {
            repository.updateAlarm(updated)
            if (updated.isEnabled) {
                AlarmScheduler.scheduleAlarm(getApplication(), updated)
            } else {
                AlarmScheduler.cancelAlarm(getApplication(), updated.id)
            }
        }
    }

    fun updateAlarmTime(alarm: AlarmItem, newHour: Int, newMinute: Int) {
        SoundVibrationHelper.triggerClickHaptic(getApplication())
        val updated = alarm.copy(hour = newHour, minute = newMinute)
        viewModelScope.launch {
            repository.updateAlarm(updated)
            if (updated.isEnabled) {
                AlarmScheduler.scheduleAlarm(getApplication(), updated)
            }
        }
    }

    fun clearTodayStats() {
        viewModelScope.launch {
            repository.clearTodayLogs()
        }
    }

    override fun onCleared() {
        super.onCleared()
        stopTimerInternal()
    }
}
