package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Calming Teal & Ocean Blue Wellness Palette
val PrimaryOcean = Color(0xFF00668B)
val OnPrimaryOcean = Color(0xFFFFFFFF)
val PrimaryContainerOcean = Color(0xFFC3E8FF)
val OnPrimaryContainerOcean = Color(0xFF001E2C)

val SecondaryTeal = Color(0xFF0D9488)
val OnSecondaryTeal = Color(0xFFFFFFFF)
val SecondaryContainerTeal = Color(0xFFCCFBF1)
val OnSecondaryContainerTeal = Color(0xFF115E59)

val AccentSuccess = Color(0xFF059669)
val AccentWarning = Color(0xFFD97706)

val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFEDF2F7)
val OutlineLight = Color(0xFFCBD5E1)
val TextPrimary = Color(0xFF0F172A)
val TextSecondary = Color(0xFF475569)

// Dark Theme Variants
val PrimaryOceanDark = Color(0xFF7BD0FF)
val BackgroundDark = Color(0xFF0F172A)
val SurfaceDark = Color(0xFF1E293B)
val SurfaceVariantDark = Color(0xFF334155)
val OutlineDark = Color(0xFF475569)
