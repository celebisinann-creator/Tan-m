package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "alarms")
data class AlarmItem(
    @PrimaryKey
    val id: Int, // 1, 2, 3, 4
    val title: String, // "Alarm 1", "Alarm 2", etc.
    val hour: Int, // 0..23
    val minute: Int, // 0..59
    val isEnabled: Boolean
) {
    val formattedTime: String
        get() = "%02d:%02d".format(hour, minute)
}
