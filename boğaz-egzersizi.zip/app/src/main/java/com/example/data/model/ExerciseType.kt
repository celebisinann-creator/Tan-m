package com.example.data.model

enum class ExerciseType(
    val id: Int,
    val displayName: String,
    val fullTitle: String,
    val subtitle: String,
    val description: String,
    val defaultDurationSeconds: Int = 180 // 3 minutes
) {
    BOGAZ_1(
        id = 1,
        displayName = "BOĞAZ 1",
        fullTitle = "BOĞAZ 1 EGZERSİZİ",
        subtitle = "Dil ve Damak Esnetme",
        description = "Dil ucunu üst damağa yaslayın, çenenizi kasmadan yavaşça ağzınızı aralayıp kapatın. Boğaz kaslarını rahatlatır."
    ),
    BOGAZ_2(
        id = 2,
        displayName = "BOĞAZ 2",
        fullTitle = "BOĞAZ 2 EGZERSİZİ",
        subtitle = "Ses Teli & Rezonans (Mmm)",
        description = "Dudaklar hafifçe kapalıyken burnunuzdan 'Mmmm' sesi çıkararak boğaz ve yüzünüzdeki titreşimi hissedin."
    ),
    BOGAZ_3(
        id = 3,
        displayName = "BOĞAZ 3",
        fullTitle = "BOĞAZ 3 EGZERSİZİ",
        subtitle = "Yutkunma & Larinks Egzersizi",
        description = "Çenenizi hafifçe yukarı kaldırıp başınızı geriye almadan kontrollü ve sakin şekilde yutkunun."
    ),
    BOGAZ_4(
        id = 4,
        displayName = "BOĞAZ 4",
        fullTitle = "BOĞAZ 4 EGZERSİZİ",
        subtitle = "Derin Boğaz & Sıcak Nefes",
        description = "Burundan sakin bir nefes alın, ağzınızı 'O' şeklinde açarak boğazdan dışarı ılık 'Haaaa' fısıltısı verin."
    );

    companion object {
        fun fromId(id: Int): ExerciseType {
            return entries.find { it.id == id } ?: BOGAZ_1
        }
    }
}
