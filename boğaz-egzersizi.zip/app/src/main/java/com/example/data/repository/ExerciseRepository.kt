package com.example.data.repository

import com.example.data.db.ExerciseDao
import com.example.data.model.AlarmItem
import com.example.data.model.ExerciseLog
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ExerciseRepository(private val dao: ExerciseDao) {

    fun getTodayDateString(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return sdf.format(Date())
    }

    val allAlarms: Flow<List<AlarmItem>> = dao.getAllAlarms()

    fun getTodayLogs(): Flow<List<ExerciseLog>> {
        return dao.getLogsForDate(getTodayDateString())
    }

    fun getAllLogs(): Flow<List<ExerciseLog>> {
        return dao.getAllLogs()
    }

    fun getTodayCountForExercise(exerciseId: Int): Flow<Int> {
        return dao.getCountForExercise(exerciseId, getTodayDateString())
    }

    suspend fun recordCompletedExercise(exerciseId: Int, durationSeconds: Int = 180) {
        val log = ExerciseLog(
            exerciseId = exerciseId,
            dateString = getTodayDateString(),
            completedAtTimestamp = System.currentTimeMillis(),
            durationSeconds = durationSeconds
        )
        dao.insertLog(log)
    }

    suspend fun clearTodayLogs() {
        dao.clearLogsForDate(getTodayDateString())
    }

    suspend fun updateAlarm(alarm: AlarmItem) {
        dao.updateAlarm(alarm)
    }

    suspend fun getAllAlarmsList(): List<AlarmItem> {
        return dao.getAllAlarmsList()
    }

    suspend fun ensureDefaultAlarms() {
        val existing = dao.getAllAlarmsList()
        if (existing.isEmpty()) {
            val defaultAlarms = listOf(
                AlarmItem(id = 1, title = "Alarm 1", hour = 8, minute = 0, isEnabled = true),
                AlarmItem(id = 2, title = "Alarm 2", hour = 12, minute = 0, isEnabled = true),
                AlarmItem(id = 3, title = "Alarm 3", hour = 17, minute = 0, isEnabled = true),
                AlarmItem(id = 4, title = "Alarm 4", hour = 21, minute = 0, isEnabled = false)
            )
            dao.insertAlarms(defaultAlarms)
        }
    }
}
