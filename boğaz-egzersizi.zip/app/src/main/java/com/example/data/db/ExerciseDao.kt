package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.AlarmItem
import com.example.data.model.ExerciseLog
import kotlinx.coroutines.flow.Flow

@Dao
interface ExerciseDao {
    // --- Exercise Logs ---
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: ExerciseLog): Long

    @Query("SELECT * FROM exercise_logs WHERE dateString = :dateString ORDER BY completedAtTimestamp DESC")
    fun getLogsForDate(dateString: String): Flow<List<ExerciseLog>>

    @Query("SELECT * FROM exercise_logs ORDER BY completedAtTimestamp DESC")
    fun getAllLogs(): Flow<List<ExerciseLog>>

    @Query("SELECT COUNT(*) FROM exercise_logs WHERE exerciseId = :exerciseId AND dateString = :dateString")
    fun getCountForExercise(exerciseId: Int, dateString: String): Flow<Int>

    @Query("DELETE FROM exercise_logs WHERE dateString = :dateString")
    suspend fun clearLogsForDate(dateString: String)

    // --- Alarms ---
    @Query("SELECT * FROM alarms ORDER BY id ASC")
    fun getAllAlarms(): Flow<List<AlarmItem>>

    @Query("SELECT * FROM alarms ORDER BY id ASC")
    suspend fun getAllAlarmsList(): List<AlarmItem>

    @Query("SELECT * FROM alarms WHERE id = :id LIMIT 1")
    suspend fun getAlarmById(id: Int): AlarmItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlarms(alarms: List<AlarmItem>)

    @Update
    suspend fun updateAlarm(alarm: AlarmItem)
}
