package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "exercise_logs")
data class ExerciseLog(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val exerciseId: Int,
    val dateString: String, // "YYYY-MM-DD"
    val completedAtTimestamp: Long = System.currentTimeMillis(),
    val durationSeconds: Int = 180
)
