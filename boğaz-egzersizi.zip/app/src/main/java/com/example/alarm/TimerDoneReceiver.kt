package com.example.alarm

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.data.db.AppDatabase
import com.example.data.model.ExerciseType
import com.example.data.repository.ExerciseRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class TimerDoneReceiver : BroadcastReceiver() {

    companion object {
        const val CHANNEL_ID = "bogaz_timer_channel"
        const val CHANNEL_NAME = "Boğaz Egzersizi Süre Sonu"
        private const val NOTIFICATION_ID = 8888
        private const val TAG = "TimerDoneReceiver"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val exerciseId = intent.getIntExtra(AlarmScheduler.EXTRA_EXERCISE_ID, 1)
        val exercise = ExerciseType.fromId(exerciseId)

        Log.d(TAG, "Timer done for exercise: ${exercise.displayName}")

        // 1. Play alert chime and vibration
        SoundVibrationHelper.playAlertSound(context, isAlarm = true)
        SoundVibrationHelper.triggerVibration(context, longArrayOf(0, 500, 200, 500, 200, 800))

        // 2. Record completion in database
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = AppDatabase.getInstance(context)
                val repo = ExerciseRepository(db.exerciseDao())
                repo.recordCompletedExercise(exercise.id, 180)
            } catch (e: Exception) {
                Log.e(TAG, "Error recording completed exercise", e)
            }
        }

        // 3. Post notification
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "3 dakikalık egzersiz süresi dolduğunda bildirim verir"
                enableVibration(true)
            }
            notificationManager.createNotificationChannel(channel)
        }

        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            NOTIFICATION_ID,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Süre Doldu: ${exercise.fullTitle}")
            .setContentText("Harika! 3 dakikalık egzersiz başarıyla tamamlandı.")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .build()

        notificationManager.notify(NOTIFICATION_ID, notification)
    }
}
