package com.example.alarm

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.db.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ExerciseAlarmReceiver : BroadcastReceiver() {

    companion object {
        const val CHANNEL_ID = "bogaz_alarms_channel"
        const val CHANNEL_NAME = "Boğaz Egzersizi Alarmları"
        private const val TAG = "ExerciseAlarmReceiver"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val alarmId = intent.getIntExtra(AlarmScheduler.EXTRA_ALARM_ID, 1)
        val alarmTitle = intent.getStringExtra(AlarmScheduler.EXTRA_ALARM_TITLE) ?: "Boğaz Egzersizi"

        Log.d(TAG, "Alarm triggered: id=$alarmId, title=$alarmTitle")

        // 1. Play loud alert sound and trigger vibration
        SoundVibrationHelper.playAlertSound(context, isAlarm = true)
        SoundVibrationHelper.triggerVibration(context, longArrayOf(0, 700, 300, 700, 300, 1000))

        // 2. Show high-priority notification
        showNotification(context, alarmId, alarmTitle)

        // 3. Reschedule this alarm for tomorrow so it repeats daily
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = AppDatabase.getInstance(context)
                val alarmItem = db.exerciseDao().getAlarmById(alarmId)
                if (alarmItem != null && alarmItem.isEnabled) {
                    AlarmScheduler.scheduleAlarm(context, alarmItem)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error rescheduling next alarm instance", e)
            }
        }
    }

    private fun showNotification(context: Context, alarmId: Int, alarmTitle: String) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        // Create channel if needed
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Günlük planlanmış boğaz egzersiz alarmları"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 700, 300, 700, 300, 1000)
            }
            notificationManager.createNotificationChannel(channel)
        }

        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("EXTRA_NAVIGATE_TO", "exercise")
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            alarmId,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Boğaz egzersizi zamanı")
            .setContentText("$alarmTitle saati geldi. Sağlıklı ses ve rahat nefes için egzersize başlayın!")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .build()

        notificationManager.notify(alarmId, notification)
    }
}
