package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.ui.ExerciseViewModel
import com.example.ui.screens.AlarmsScreen
import com.example.ui.screens.MainExerciseScreen
import com.example.ui.screens.StatsScreen
import com.example.ui.theme.BogazEgzersiziTheme

enum class AppTab(
    val route: String,
    val title: String,
    val icon: ImageVector,
    val testTag: String
) {
    EXERCISE("exercise", "Egzersiz", Icons.Default.Timer, "tab_exercise"),
    ALARMS("alarms", "Alarmlar", Icons.Default.Alarm, "tab_alarms"),
    STATS("stats", "İstatistik", Icons.Default.Assessment, "tab_stats")
}

class MainActivity : ComponentActivity() {

    private val viewModel: ExerciseViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            BogazEgzersiziTheme {
                BogazAppMainScreen(
                    viewModel = viewModel,
                    initialTab = parseInitialTab(intent)
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
    }

    private fun parseInitialTab(intent: Intent?): AppTab {
        return when (intent?.getStringExtra("EXTRA_NAVIGATE_TO")) {
            "alarms" -> AppTab.ALARMS
            "stats" -> AppTab.STATS
            else -> AppTab.EXERCISE
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BogazAppMainScreen(
    viewModel: ExerciseViewModel,
    initialTab: AppTab = AppTab.EXERCISE
) {
    var selectedTab by remember { mutableStateOf(initialTab) }
    val lifecycleOwner = LocalLifecycleOwner.current

    // Sync elapsed time when app returns to foreground
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.onAppForegrounded()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    // Handle back button on sub-screens: returns to exercise screen
    BackHandler(enabled = selectedTab != AppTab.EXERCISE) {
        selectedTab = AppTab.EXERCISE
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = when (selectedTab) {
                            AppTab.EXERCISE -> "Boğaz Egzersizi"
                            AppTab.ALARMS -> "Egzersiz Alarmları"
                            AppTab.STATS -> "Günlük İstatistik"
                        },
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp,
                modifier = Modifier.testTag("bottom_nav_bar")
            ) {
                AppTab.entries.forEach { tab ->
                    val isSelected = selectedTab == tab
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { selectedTab = tab },
                        icon = {
                            Icon(
                                imageVector = tab.icon,
                                contentDescription = tab.title
                            )
                        },
                        label = {
                            Text(
                                text = tab.title,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer
                        ),
                        modifier = Modifier.testTag(tab.testTag)
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                AppTab.EXERCISE -> MainExerciseScreen(viewModel = viewModel)
                AppTab.ALARMS -> AlarmsScreen(viewModel = viewModel)
                AppTab.STATS -> StatsScreen(viewModel = viewModel)
            }
        }
    }
}
