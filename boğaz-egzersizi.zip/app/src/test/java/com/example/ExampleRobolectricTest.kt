package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.ExerciseType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Boğaz Egzersizi", appName)
    }

    @Test
    fun `verify four throat exercises configuration`() {
        assertEquals(4, ExerciseType.entries.size)
        assertEquals("BOĞAZ 1", ExerciseType.BOGAZ_1.displayName)
        assertEquals("BOĞAZ 2", ExerciseType.BOGAZ_2.displayName)
        assertEquals("BOĞAZ 3", ExerciseType.BOGAZ_3.displayName)
        assertEquals("BOĞAZ 4", ExerciseType.BOGAZ_4.displayName)
        assertEquals(180, ExerciseType.BOGAZ_1.defaultDurationSeconds)
    }
}
